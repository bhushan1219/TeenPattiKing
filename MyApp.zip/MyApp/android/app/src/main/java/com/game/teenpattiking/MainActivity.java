package com.game.teenpattiking;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
